from tkinter import*
import tkinter.messagebox
#import stdDatabase
import sqlite3
import random
import time;

#class for front end UI
class Email:
    def __init__(self,root):

        '''creat object reference instance of databse class'''
        p = Database()
        p.conn()

        self.root = root
        self.root.title("PASSWORD MANAGEMENT SYSTEM")
        self.root.geometry("1300x700+0+0")
        self.root.config(bg = 'white')

        handlename = StringVar()
        emaill = StringVar()
        passwrd = StringVar()
        judgeName = StringVar()

        '''Lets call the database method to perform database'''
        #function for close
        def close():
            print("Email : close method called")
            close = tkinter.messagebox.askyesno("PASSWORD MANAGEMENT SYSTEM","Really  want to Exit ?")
            if close > 0:
                root.destroy()
                print("Email : close method finished")
                return
        #function for clear the widgets
        def clear():
            print("Email : clear method called")
            self.txtjudgeName.delete(0,END)
            self.txthandlename.delete(0,END)
            self.txtemaill.delete(0,END)
            self.txtpasswrd.delete(0,END)
            print("Email : clear method finished")

       #function to save the product details in database table
        def insert():
            print("Email : insert method called")
            if(len(handlename.get())!=0):
                p.insert(judgeName.get(),handlename.get(),emaill.get(),passwrd.get())
                productList.delete(0,END)
                productList.insert(END,judgeName.get(),handlename.get(),emaill.get(),passwrd.get())
                showInproductList()  #called showInproductList method after inserting data to database table

            else :
                tkinter.messagebox.askyesno("PASSWORD MANAGEMENT SYSTEM","Really  want to Enter Data?")
            print("Email : insert method finished")

       #function to show the email table data to scroollbar
        def showInproductList():
            print("Email : showInproductList method called")
            productList.delete(0,END)
            for row in p.show():
                productList.insert(END,row,str(""))
            print("Email : showInproductList method finished")

        #add to Scrollbar
        def prodctRec(event):  #function to be called from scrollbar productList
            print("Email : prodctRec method called")
            global pd

            searchPd = productList.curselection()[0]
            pd = productList.get(searchPd)

            self.txtjudgeName.delete(0,END)
            self.txtjudgeName.insert(END,pd[0])

            self.txthandlename.delete(0,END)
            self.txthandlename.insert(END,pd[1])

            self.txtemaill.delete(0,END)
            self.txtemaill.insert(END,pd[2])

            self.txtpasswrd.delete(0,END)
            self.txtpasswrd.insert(END,pd[3])

            print('Email : prodctRec method finished')

        #function delete the data from database textvariable
        def delete():
            print("Email : delete method called")
            if(len(judgeName.get())!=0):
                p.delete(pd[0])
                clear()
                showInproductList()
            print("Email : delete method finished")

        #search method called
        def search():
            print("Email : search method called")
            productList.delete(0,END)
            for row in p.search(judgeName.get(),handlename.get(),emaill.get(),passwrd.get()):
                productList.insert(END,row,str(""))

            print("Email : search method finished")

      #function update the record
        def update():
            print("Email : update method called")
            if(len(judgeName.get())!=0):
                print("pd[0]",pd[p])
                p.delete(pd[0])
            if(len(judgeName.get())!=0):
                p.insert(judgeName.get(),handlename.get(),emaill.get(),passwrd.get())
                productList.delete(0,END)
            productList.insert(END,(judgeName.get(),handlename.get(),emaill.get(),passwrd.get()))
            print("Email : update method finished")


       #Frame works

        MainFrame = Frame(self.root)
        MainFrame.grid()

        HeaderFrame = Frame(MainFrame,bd=2, padx = 54,bg = 'yellow',relief=RIDGE)
        HeaderFrame.pack(side=TOP, fill=X)

        self.ITitle = Label(HeaderFrame, font = ('times new roman',47,'bold'),bd=9,text = '  Password Management System',bg = "yellow",fg="red" )
        self.ITitle.grid()

        operationFrame = Frame(MainFrame,bd = 2,width = 1350, height = 70,padx = 18, pady = 10,bg = "#40E0D0",relief=RIDGE)
        operationFrame.pack(side = BOTTOM)

        BodyFrame = Frame(MainFrame,bd = 2,width = 1290, height = 400,padx = 30, pady = 20,bg = "white",relief=RIDGE)
        BodyFrame.pack(side = BOTTOM)

        LeftBodyFrame = LabelFrame(BodyFrame,bd = 2,width = 450, height = 560,padx = 20, pady = 10,bg = "#40E0D0",relief=RIDGE, font= ('arial',20,'bold'),text = "Password Info:" )
        LeftBodyFrame.pack(side = LEFT)

        RightBodyFrame = LabelFrame(BodyFrame,bd = 2,width = 450, height = 560,padx = 20, pady = 10,bg = "#40E0D0",relief=RIDGE, font= ('arial',20,'bold'),text = "Store data:" )
        RightBodyFrame.pack(side = RIGHT)

        '''Add the widgets to LeftbodyFrame'''

        self.labeljudgeName = Label(LeftBodyFrame, font = ('arial',15,'bold'), text = "Plateform:",padx = 2,bg = "blue",fg= "white")
        self.labeljudgeName.grid(row = 0,column = 0, sticky = "W")
        self.txtjudgeName = Entry(LeftBodyFrame, font = ('arial',15,'bold'),textvariable = judgeName, width = 35)
        self.txtjudgeName.grid(row = 0,column = 1, sticky = "W",padx=10,pady=20)

        self.labelhandlename = Label(LeftBodyFrame, font = ('arial',15,'bold'), text = "Username:",padx = 2,bg = "blue",fg= "white")
        self.labelhandlename.grid(row = 1,column = 0, sticky = "W")
        self.txthandlename = Entry(LeftBodyFrame, font = ('arial',15,'bold'),textvariable = handlename, width = 35)
        self.txthandlename.grid(row = 1,column = 1, sticky = "W",padx=10,pady=20)

        self.labelemaill = Label(LeftBodyFrame, font = ('arial',15,'bold'), text = "Email:",bg = "blue",fg= "white")
        self.labelemaill.grid(row = 2,column = 0, sticky = "W",padx=10,pady=20)
        self.txtemaill = Entry(LeftBodyFrame, font = ('arial',15,'bold'),textvariable = emaill, width = 35)
        self.txtemaill.grid(row = 2,column = 1, sticky = "W",padx=10,pady=20)

        self.labelpasswrd = Label(LeftBodyFrame, font = ('arial',15,'bold'), text = "Password:",bg = "blue",fg= "white")
        self.labelpasswrd.grid(row = 3,column = 0, sticky = "W")
        self.txtpasswrd = Entry(LeftBodyFrame, font = ('arial',15,'bold'),textvariable = passwrd, width = 35)
        self.txtpasswrd.grid(row = 3,column = 1, sticky = "W",padx=10,pady=20)

        self.labelpasswrd1 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd1.grid(row = 4,column = 0, sticky = "W")

        self.labelpasswrd2 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd2.grid(row = 5,column = 0, sticky = "W")

        self.labelpasswrd3 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd3.grid(row = 6,column = 0, sticky = "W")

        self.labelpasswrd4 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd4.grid(row = 7,column = 0, sticky = "W")

        self.labelpasswrd5 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd5.grid(row = 8,column = 0, sticky = "W")

        self.labelpasswrd6 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd6.grid(row = 9,column = 0, sticky = "W")

        self.labelpasswrd7 = Label(LeftBodyFrame,padx = 1)
        self.labelpasswrd7.grid(row = 10,column = 0, sticky = "W")



        '''Right body = Adding scroll bar'''

        scroll = Scrollbar(RightBodyFrame)
        scroll.grid(row=0, column = 1, sticky = 'ns')

        productList=Listbox(RightBodyFrame, width = 55, height = 17, font = ('arial',15,'bold'),
                   yscrollcommand = scroll.set)

        #called above created prodctRec function of init
        productList.bind('<<ListboxSelect>>',prodctRec)

        productList.grid(row = 0, column = 0,padx = 8)
        scroll.config(command = productList.yview)

        '''Adding buttons to operation frame'''

        self.buttonSave = Button(operationFrame, text = 'Save',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4,command = insert)
        self.buttonSave.grid(row = 0,column = 0)

        self.buttonShow = Button(operationFrame, text = 'Display',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4, command = showInproductList)
        self.buttonShow.grid(row = 0,column = 1)

        self.buttonClear = Button(operationFrame, text = 'Clear',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4, command = clear)
        self.buttonClear.grid(row = 0,column = 2)

        self.buttonDelete = Button(operationFrame, text = 'Delete',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4,command = delete)
        self.buttonDelete.grid(row = 0,column = 3)

        self.buttonUpdate = Button(operationFrame, text = 'Update',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4)
        self.buttonUpdate.grid(row = 0,column = 4)

        self.buttonSearch = Button(operationFrame, text = 'Search',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4, command = search)
        self.buttonSearch.grid(row = 0,column = 5)

        self.buttonExit = Button(operationFrame, text = 'Exit',font = ('arial',15,'bold'),bg = "yellow",fg="red",height = 1, width = '12',bd =4,command = close)
        self.buttonExit.grid(row = 0,column = 6)

'''Back End Database operations'''

class Database:
    def conn(self):
        print("Database : connection method called")
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        query = "create table if not exists email(judgeName text,handlename text primary key,\
             emaill text, passwrd text )"
        cur.execute(query)
        con.commit()
        con.close()
        print("Database : connection method finished")

    def insert(self,judgeName,handlename,emaill,passwrd):
        print("Database : insert method called")
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        query = "insert into email values(?,?,?,?)"
        cur.execute(query,(judgeName,handlename,emaill,passwrd))
        con.commit()
        con.close()
        print("Database : insert method finished")

    def show(self):
        print("Database : Show method called")
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        query = "select * from email"
        cur.execute(query)
        rows = cur.fetchall()
        con.close()
        print("Database : show method finished")
        return rows

    def delete(self,judgeName):
        print("Database : Delete method called",judgeName)
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        cur.execute("delete from email where judgeName=?",(judgeName,))
        con.commit()
        con.close()
        print(judgeName,"Database : delete method finished")

    def search(self,judgeName="",handlename="",emaill = "",passwrd = ""):
        print("Database : Search method called")
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        cur.execute("select * from email where judgeName=? or handlename=? or emaill = ? or passwrd =?",(judgeName,handlename,emaill,passwrd))
        row = cur.fetchall()
        con.close()
        print(handlename,"Database : search method finished")
        return row

    def update(self,judgeName="",handlename="",emaill = "",passwrd = ""):
        print("Database : Update method called")
        con = sqlite3.connect("inventory.db")
        cur = con.cursor()
        cur = con.cursor()
        cur.execute("update email set judgeName=? or handlename=? or emaill = ? or passwrd =?",(judgeName,handlename,emaill,passwrd) )
        con.commit()
        con.close()
        print(handlename,"Database : update method finished")


if __name__=='__main__':
    root = Tk()
    application = Email(root)
    root.mainloop()
